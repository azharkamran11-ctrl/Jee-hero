JEE HERO — ALTAMAS EDITION (Android project)

This is the Android WebView wrapper for the JEE HERO app.
The APK is not included because this workspace has no Android SDK/build tools.

To build:
1. Create a GitHub repository and upload all files/folders in this project.
2. Open the repository's Actions tab.
3. Run "Build JEE HERO APK" (or push to main).
4. Open the completed workflow run and download the "JEE-HERO-APK" artifact.
5. Extract it and install app-debug.apk on your Android phone. You may need to allow installation from your browser/files app.

This creates a debug APK for personal testing, not a Play Store release.
